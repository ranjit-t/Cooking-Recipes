# Cooking Recipes App with React

## Technologies Used

1. CSS
2. React

## How to Run this project

1. Download the zip file from github.
2. just add the node modules folder to the project or install dependencies.
3. run ( npm start ) command and there you go!
